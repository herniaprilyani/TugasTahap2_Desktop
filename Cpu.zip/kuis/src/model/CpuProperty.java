/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author user
 */
public class CpuProperty {

    private StringProperty id;
    private StringProperty merek;
    private StringProperty harga;
    private StringProperty warna;
    private StringProperty tanggal;

    public CpuProperty(String id, String merek, String harga, String warna, String tanggal) {
        this.id = new SimpleStringProperty(id);
        this.merek = new SimpleStringProperty(merek);
        this.harga = new SimpleStringProperty(harga);
        this.warna = new SimpleStringProperty(warna);
        this.tanggal = new SimpleStringProperty(tanggal);
    }

    public CpuProperty(Cpu datacpu) {
        this.id = new SimpleStringProperty(datacpu.getId());
        this.merek = new SimpleStringProperty(datacpu.getMerek());
        this.harga = new SimpleStringProperty(datacpu.getHarga());
        this.warna = new SimpleStringProperty(datacpu.getWarna());
        this.tanggal = new SimpleStringProperty(datacpu.getTanggal());
    }

    public StringProperty getIdProperty() {
        return id;
    }

    public void setId(String id) {
        this.id = new SimpleStringProperty(id);
    }

    public StringProperty getMerekProperty() {
        return merek;
    }

    public void setMerek(String merek) {
        this.merek = new SimpleStringProperty(merek);
    }

    public StringProperty getHargaProperty() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = new SimpleStringProperty(harga);
    }

    public StringProperty getWarnaProperty() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = new SimpleStringProperty(warna);
    }

    public StringProperty getTanggalProperty() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = new SimpleStringProperty(tanggal);
    }
    
    public String getId() {
        return id.get();
    }

    public String getMerek() {
        return merek.get();
    }

    public String getHarga() {
        return harga.get();
    }

    public String getWarna() {
        return warna.get();
    }

    public String getTanggal() {
        return tanggal.get();
    }
    
  
}
