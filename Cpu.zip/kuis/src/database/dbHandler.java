/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;
import model.Cpu;
import model.CpuProperty;

public class dbHandler {
    public final Connection conn;

    public dbHandler(String driver) {
        this.conn = dbHelper.getConnection(driver);
    }
    public void addCPU(Cpu datacpu){
        String insertDatacpu = "INSERT INTO `datacpu`(`id`, `merek`,`harga`,`warna`,`tanggal`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertDatacpu);
            stmtInsert.setString(1, datacpu.getId());
            stmtInsert.setString(2, datacpu.getMerek());
            stmtInsert.setString(3, datacpu.getHarga());
            stmtInsert.setString(4, datacpu.getWarna());
            stmtInsert.setString(5, datacpu.getTanggal());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(dbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public ObservableList<CpuProperty> getCpu(){
        ObservableList<CpuProperty> data = FXCollections.observableArrayList();
        
        String sql = "SELECT id, merek, harga, warna, tanggal FROM `datacpu` ORDER BY id";
        
        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                CpuProperty datacpu = new CpuProperty(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
                data.add(datacpu);
            }
        } catch (SQLException ex) {
            Logger.getLogger(dbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return data;
    }
    public void deleteCpu(CpuProperty datacpu){
        String deleteDatacpu = "DELETE FROM datacpu WHERE `datacpu`.`id` = ?";
        try {
            PreparedStatement stmtDelete = conn.prepareStatement(deleteDatacpu);
            stmtDelete.setString(1, datacpu.getId());
            stmtDelete.execute();
        } catch (SQLException ex) {
            Logger.getLogger(dbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void editCpu(CpuProperty datacpu){
        String updateDatacpu= "UPDATE INTO `datacpu`SET (`id`, `merek`,`harga`,`warna`,`tanggal`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtUpdate = conn.prepareStatement(updateDatacpu);
            stmtUpdate.setString(1, datacpu.getId());
            stmtUpdate.setString(2, datacpu.getMerek());
            stmtUpdate.setString(3, datacpu.getHarga());
            stmtUpdate.setString(4, datacpu.getWarna());
            stmtUpdate.setString(5, datacpu.getTanggal());
            stmtUpdate.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(dbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}